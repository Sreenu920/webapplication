
package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.employee.EmpdetailsRepository;

@Controller
public class MainController {
	
	@GetMapping("")
	public String viewHomePage() {
		return "index";
	}
	
	@GetMapping("/hr/login")
	public String viewHrLoginPage() {
		return "hr/hr_login";
	}
	
	@GetMapping("/employee/login")
	public String viewEmployeeLoginPage() {
		return "employee/employee_login";
	}
	@GetMapping("/hr/home")
	public String viewHrhomePage() {
		return "hr/hr_home";
	}
	@GetMapping("/employee/home")
	public String viewEmployeehomePage() {
		return "employee/employee_home";
	}
	@GetMapping("/employee/details")
	public String viewPersoneldetailsPage() {
		return "employee/personel_details";
	}
	@GetMapping("/hr/details")
	public String viewPersoneldetails1Page() {
		return "hr/personel_details1";
		
	}
	@GetMapping("/employee/home1")
	public String viewhomePage() {
		return "employee/home";
	}
	@GetMapping("/hr/home1")
	public String viewhomePage1() {
		return "hr/home1";
	}


	@GetMapping("/employee/calender")
	public String viewEmployeecalenderPage() {
		return "employee/calender1";
	}
	
	@GetMapping("/hr/calender")
	public String viewHRcalenderPage() {
		return "hr/calender2";
	}
	
	
	
	
}
