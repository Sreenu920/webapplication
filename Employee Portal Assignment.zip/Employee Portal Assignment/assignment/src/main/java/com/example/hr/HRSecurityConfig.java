package com.example.hr;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@Order(1)
public class HRSecurityConfig {
	
	
	@Bean
	public UserDetailsService userDetailsService() {
		return new CustomUserDetailService();
	}
	
	@Bean
	public PasswordEncoder passwordEncoder1() {
		return NoOpPasswordEncoder.getInstance();
		
	}
	@Bean
	public DaoAuthenticationProvider authenticationProvider1() {
		DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
		provider.setUserDetailsService(userDetailsService());
		provider.setPasswordEncoder(passwordEncoder1());
		
		return provider;
	}

	@Bean
	public SecurityFilterChain filterChain1(HttpSecurity http) throws Exception {
		http.authenticationProvider(authenticationProvider1());
		
		http.securityMatcher("/hr/**")
		    .authorizeRequests().anyRequest().authenticated()
		    .and()
		    .formLogin()
		         .loginPage("/hr/login")
		         .usernameParameter("email")
		         .loginProcessingUrl("/hr/login")
		         .defaultSuccessUrl("/hr/home")
		         .permitAll()
		    .and()
		         .logout().logoutUrl("/hr/logout")
		         .logoutSuccessUrl("/");
		
		return http.build();
	}
}
