package com.example.employee;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

import com.example.hr.CustomUserDetailService;

@Configuration
@Order(2)
public class EmployeeSecurityConfig {
	
	@Bean
	public UserDetailsService employeeDetailsService() {
		return new EmployeeUserDetailService();
	}
	
	@Bean
	public PasswordEncoder passwordEncoder2() {
		return NoOpPasswordEncoder.getInstance();
		
	}
	
	@Bean
	public DaoAuthenticationProvider authenticationProvider2() {
		DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
		provider.setUserDetailsService(employeeDetailsService());
		provider.setPasswordEncoder(passwordEncoder2());
		
		return provider;
	}

	@Bean
	public SecurityFilterChain filterChain2(HttpSecurity http) throws Exception {
		http.authenticationProvider(authenticationProvider2());
		
		http.securityMatcher("/employee/**")
		    .authorizeRequests().anyRequest().authenticated()
		    .and()
		    .formLogin()
		         .loginPage("/employee/login")
		         .usernameParameter("email")
		         .loginProcessingUrl("/employee/login")
		         .defaultSuccessUrl("/employee/home")
		         .permitAll()
		    .and()
		         .logout().logoutUrl("/employee/logout")
		         .logoutSuccessUrl("/");
		
		return http.build();
	}
}
