package com.example.hr;
import java.util.List;

//import org.springframework.data.repository.CrudRepository;
import org.springframework.data.jpa.repository.JpaRepository;

// This will be AUTO IMPLEMENTED by Spring into a Bean called userRepository
// CRUD refers Create, Read, Update, Delete

//public interface EmployeeRepository extends jpaRepository<Employee, Integer> {
	
//	public Employee findByid(int id);
	
public interface HRdetailsRepository extends JpaRepository<HRdetails, String> {
	
	List<HRdetails> findAllByemail(String email);
	

}
