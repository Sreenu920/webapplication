package com.example.hr;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

public interface userRepository extends CrudRepository<user, Integer>{
	public user findByEmail(String email);

}
