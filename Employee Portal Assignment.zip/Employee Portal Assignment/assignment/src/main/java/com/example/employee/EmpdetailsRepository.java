package com.example.employee;
import java.util.List;

//import org.springframework.data.repository.CrudRepository;
import org.springframework.data.jpa.repository.JpaRepository;

// This will be AUTO IMPLEMENTED by Spring into a Bean called userRepository
// CRUD refers Create, Read, Update, Delete

//public interface EmployeeRepository extends jpaRepository<Employee, Integer> {
	
//	public Employee findByid(int id);
	
public interface EmpdetailsRepository extends JpaRepository<Empdetails, String> {
	
	List<Empdetails> findAllByemail(String email);
	

}