package com.example.hr;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

public class CustomUserDetailService implements UserDetailsService {
	@Autowired private userRepository repo;
	

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		user user = repo.findByEmail(username);
		
		if(user == null) {
			throw new UsernameNotFoundException("No user found for the given email");
		}
	
		return new CustomUserDetails(user);
	}

	
}
