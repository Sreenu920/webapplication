package com.example.employee;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.example.hr.CustomUserDetails;

public class EmployeeUserDetailService implements UserDetailsService {
	@Autowired private EmployeeRepository repo;
	

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		 Employee employee = repo.findByEmail(username);
		
		if(employee == null) {
			throw new UsernameNotFoundException("No employee found for the given email");
		}
	
		return new EmployeeUserDetails(employee);
	}

	
}
