package net.codejava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeAcessPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
